<?php
//Header
include_once 'includes/header.php';
?>
    <div class="section no-pad-bot" id="index-banner">
      <div class="container">
        <br /><br />
        <div class="globaldiv">

          <div class="row center">
            <div class="col s12 m6 l6 x16">
              <div class="imgdohome">
                <img src="assets/imagens/logoo.svg"/></a>
              </div>
              <div class="col s12 m6 l6 x16">
                <a href="#" id="download-button"
                class="btn-large waves-effect waves-light azul-marinho">Entrar</a>              
              </div>
              
              <div class="col s12 m6 l6 x16">
                <a id="logo-index">
              </div>
              </div>
                <br /><br />
            </div>
         </div>
    </div>

  <?php
  //Footer
    include_once 'includes/footer.php';
  ?>